#coding=utf-8 
import pickle

def savedic(filename, dic):
    f = open(filename, 'wb')
    pickle.dump(dic, f)    
    f.close()

def readdic(filename):
    pkl_file = open(filename, 'rb')
    return pickle.load(pkl_file)
