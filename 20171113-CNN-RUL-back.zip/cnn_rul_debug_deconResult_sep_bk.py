#coding=utf-8
import pandas as pd
import numpy as np
import tensorflow as tf
from sklearn.preprocessing import scale
import pdb
#---------------
#滑动窗口
def windows(nrows, size): #（数据行数，窗口打下）
    start,step = 0, 2     # 窗口开始位置，窗口滑动步长
    while start < nrows:
        yield start, start + size #返回窗口的起始位置
        start += step

#数据分段
def segment_signal(features,labels,window_size = 15): #（特征数据，数据对应标签，窗口大小默认15）
    segments = np.empty((0,window_size)) #返回未初始化的shape形状数据，此处相当于声明了个15列的变量
    segment_labels = np.empty((0)) #此处相当于申请了变量
    nrows = len(features) 
    for (start, end) in windows(nrows,window_size): #从生成器返回所有的窗口
        if(len(data.iloc[start:end]) == window_size):
            segment = features[start:end].T  #转置，得到24 x 15，相当于一个属性一行 
            label = labels[(end-1)]
            segments = np.vstack([segments,segment]) #垂直堆叠
            segment_labels = np.append(segment_labels,label) #一行数据
    segments = segments.reshape(-1,24,window_size,1) #batch_size不用管所以设为-1，channel也设为1 
    segment_labels = segment_labels.reshape(-1,1) #获得一列，行数根据实际展开
    return segments,segment_labels

#---------------	
#读取数据
data = pd.read_csv("PHM08.csv")#, nrows=50)
features = scale(data.iloc[:,2:26]) # select required columns and scale them
labels = data.iloc[:,26] # select RU

#print features.head()
#print labels.head()

#---------------
#获得分段数据
segments, labels = segment_signal(features,labels)
#pdb.set_trace()

#---------------
#拆分训练+测试数据
train_test_split = np.random.rand(len(segments)) < 0.70 #rand根据shape生成0~1的随机数，train_test_split有70%为true，30%false
train_x = segments[train_test_split] #相当于随机了70%作为输入
train_y = labels[train_test_split]
test_x = segments[~train_test_split]
test_y = labels[~train_test_split]

#---------------
#得到权重变量
def weight_variable(shape):
    initial = tf.truncated_normal(shape, stddev = 0.1) #截断的随机分布输出，保证生成值在均值附近
    return tf.Variable(initial)

#得到偏置变量
def bias_variable(shape):
    initial = tf.constant(1.0, shape = shape)
    return tf.Variable(initial)

#卷积
#num_channels：可理解为当前层的feature map的个数（filter个数）
#depth：是将要得到的feature map个数（filter个数）
def apply_conv(x,kernel_height,kernel_width,num_channels,depth):
    weights = weight_variable([kernel_height, kernel_width, num_channels, depth])
    biases = bias_variable([depth])
    return weights, biases, tf.nn.relu(tf.add(tf.nn.conv2d(x, weights,[1,1,1,1],padding="VALID"),biases)) #relu:计算激活函数，即max(features, 0)

#max pool
#stride_size：步幅大小，应用max后向后滑动的元素个数    
def apply_max_pool(x,kernel_height,kernel_width,stride_size):
    return tf.nn.max_pool(x, ksize=[1, kernel_height, kernel_width, 1], strides=[1, 1, stride_size, 1], padding = "VALID")

#---------------	
#基本常量
num_labels = 1
batch_size = 2
num_hidden = 800
learning_rate = 0.0001
training_epochs = 30
input_height = 24
input_width = 15
num_channels = 1
total_batches = train_x.shape[0] #有多少个24*15的segment

#---------------
X = tf.placeholder(tf.float32, shape=[None,input_height,input_width,num_channels])
Y = tf.placeholder(tf.float32, shape=[None,num_labels])

#定义两个卷积和pool层
w1, b1, c1 = apply_conv(X, kernel_height = 24, kernel_width = 4, num_channels = 1, depth = 8) 
p1 = apply_max_pool(c1,kernel_height = 1, kernel_width = 2, stride_size = 2) 
w2, b2, c2 = apply_conv(p1, kernel_height = 1, kernel_width = 3, num_channels = 8, depth = 14) 
p2 = apply_max_pool(c2,kernel_height = 1, kernel_width = 2, stride_size = 2) 

shape = p2.get_shape().as_list()
flat = tf.reshape(p2, [-1, shape[1] * shape[2] * shape[3]])#横向展开

#前向传播

#输入计算
f_weights = weight_variable([shape[1] * shape[2] * shape[3], num_hidden])
f_biases = bias_variable([num_hidden])
f = tf.nn.tanh(tf.add(tf.matmul(flat, f_weights),f_biases))

#输出计算
out_weights = weight_variable([num_hidden, num_labels])
out_biases = bias_variable([num_labels])
y_ = tf.add(tf.matmul(f, out_weights),out_biases)

#---------------
#后向传播
cost_function = tf.reduce_mean(tf.square(y_- Y))#损失函数
optimizer = tf.train.AdamOptimizer(learning_rate).minimize(cost_function)#梯度下降

#load the model
import helpFunctions as hf
model = hf.readdic("model.pkl")

'''
import time
f = open("output_cnn_rul_debug.txt", "a+")
f.write(time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))+"\n")
f.write("-------------------\n")
'''
'''
import deconvFunctions as deconv

def reconstruction(w, b, c, p):
    unpool = deconv.unpooling(c, p, 2, 2)
    unrelu = tf.nn.relu(unpool)
    deconv_ = tf.nn.conv2d_transpose(unrelu, w, output_shape=model['l1_input_shape'], strides=model['l1_kernal_stride'], padding='SAME')
    return deconv_


#第一层重构
unpool1 = deconv.unpooling(c1, p1, 2, 2)
unrelu1 = tf.nn.relu(unpool1)
deconv1 = tf.nn.conv2d_transpose(unrelu1, w1, output_shape=model['l1_input_shape'], strides=model['l1_kernal_stride'], padding='SAME')#output_shape=[1, 24, 15, 1], strides=[1, 1, 1, 1], 'SAME')

#第二层重构
unpool2 = deconv.unpooling(c2, p2, 2, 2)
unrelu2 = tf.nn.relu(unpool2)
deconv2 = tf.nn.conv2d_transpose(unrelu2, w2, output_shape=model['l2_input_shape'], strides=model['l2_kernal_stride'], padding='SAME')
'''

#---------------
#计算图
with tf.Session() as session:
    tf.global_variables_initializer().run()
    tf.assign_add(w1,model['l1_w'])
    tf.assign_add(b1,model['l1_b'])
    tf.assign_add(w2,model['l2_w'])
    tf.assign_add(b2,model['l2_b'])
    tf.assign_add(f_weights,model['f_input_w'])
    tf.assign_add(f_biases,model['f_input_b'])
    tf.assign_add(out_weights,model['f_output_w'])
    tf.assign_add(out_biases,model['f_output_b'])
    
    #pdb.set_trace()

    '''
    got the trained kernal
    以上训练得到了训练好的CNN模型
    以下输入一张“图片”，在每一层卷积层附加反卷积操作
    1. get the top kernals
    2. deconv back and check with the original input
    '''

    import deconvFunctions as deconv
    model_rev = {}
    l1 = np.array(list())
    l2 = np.array(list())
    num = 10 #range(test_x.shape[0])
    for i in range(10):
        im = test_x[i:(i+1)]
       
        #feed a test ‘image’
        p1_v = session.run(p1, feed_dict={X:im})#deconv.get_activations(w1)
        c1_v = session.run(c1, feed_dict={X:im})
        w1_v = session.run(w1, feed_dict={X:im})
        
        p2_v = session.run(p2, feed_dict={X:im})
        c2_v = session.run(c2, feed_dict={X:im})
        w2_v = session.run(w2, feed_dict={X:im})

        #pdb.set_trace()

        #分别重构回去
        #第一层特征重构
        l1_recons = np.array(list())
        for j in range(c1_v.shape[-1]):
            c1_v_t = c1_v[...,j]
            c1_v_t = c1_v_t[...,np.newaxis]
            unrelu1 = tf.nn.relu(c1_v_t)
            w1_v_t = w1_v[...,j]
            w1_v_t = w1_v_t[...,np.newaxis]
            deconv1 = tf.nn.conv2d_transpose(unrelu1, w1_v_t, output_shape=model['l1_input_shape'], strides=model['l1_kernal_stride'], padding='VALID')
            
            res = session.run(deconv1)
            if j==0:
                l1_recons = res
            else:
                l1_recons = np.append(l1_recons, res, axis=3)
        
        #pdb.set_trace()
        
        #第二层特征重构
        l2_recons = np.array(list())
        for j in range(c2_v.shape[-1]):
            c2_v_t = c2_v[...,j]
            c2_v_t = c2_v_t[...,np.newaxis]
            unrelu2 = tf.nn.relu(c2_v_t)
            w2_v_t = w2_v[...,j]
            w2_v_t = w2_v_t[...,np.newaxis]
            deconv2 = tf.nn.conv2d_transpose(unrelu2, w2_v_t, output_shape=model['l2_input_shape'], strides=model['l2_kernal_stride'], padding='VALID')
            res = session.run(deconv2)
            unpool1 = deconv.apply_unpool(c1_v, res, 2, 2)
            unrelu1 = tf.nn.relu(unpool1)
            deconv1 = tf.nn.conv2d_transpose(unrelu1, w1_v, output_shape=model['l1_input_shape'], strides=model['l1_kernal_stride'], padding='VALID')
            res = session.run(deconv1)
            if j==0 :
                l2_recons = res
            else:
                l2_recons = np.append(l2_recons, res, axis=3)
    
        if i==0 :
            l1 = l1_recons
            l2 = l2_recons
        else:
            l1 = np.append(l1, l1_recons, axis=0)
            l2 = np.append(l2, l2_recons, axis=0)
        
        #pdb.set_trace()
    
    model_rev['input'] = test_x[0:num]
    model_rev['l1'] = l1
    model_rev['l2'] = l2
    
    import helpFunctions as hf
    hf.savedic('model_rev.pkl',model_rev)

    #pdb.set_trace()

