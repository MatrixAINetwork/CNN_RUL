#coding=utf-8
import pandas as pd
import numpy as np
import tensorflow as tf
from sklearn.preprocessing import scale
import pdb
#---------------
#滑动窗口
def windows(nrows, size): #（数据行数，窗口打下）
    start,step = 0, 2     # 窗口开始位置，窗口滑动步长
    while start < nrows:
        yield start, start + size #返回窗口的起始位置
        start += step

#数据分段
def segment_signal(features,labels,window_size = 15): #（特征数据，数据对应标签，窗口大小默认15）
    segments = np.empty((0,window_size)) #返回未初始化的shape形状数据，此处相当于声明了个15列的变量
    segment_labels = np.empty((0)) #此处相当于申请了变量
    nrows = len(features) 
    for (start, end) in windows(nrows,window_size): #从生成器返回所有的窗口
        if(len(data.iloc[start:end]) == window_size):
            segment = features[start:end].T  #转置，得到24 x 15，相当于一个属性一行 
            label = labels[(end-1)]
            segments = np.vstack([segments,segment]) #垂直堆叠
            segment_labels = np.append(segment_labels,label) #一行数据
    segments = segments.reshape(-1,24,window_size,1) #batch_size不用管所以设为-1，channel也设为1 
    segment_labels = segment_labels.reshape(-1,1) #获得一列，行数根据实际展开
    return segments,segment_labels

#---------------	
#读取数据
data = pd.read_csv("PHM08.csv")#, nrows=50)
features = scale(data.iloc[:,2:26]) # select required columns and scale them
labels = data.iloc[:,26] # select RU

#print features.head()
#print labels.head()

#---------------
#获得分段数据
segments, labels = segment_signal(features,labels)
#pdb.set_trace()

#---------------
#拆分训练+测试数据
train_test_split = np.random.rand(len(segments)) < 0.70 #rand根据shape生成0~1的随机数，train_test_split有70%为true，30%false
train_x = segments[train_test_split] #相当于随机了70%作为输入
train_y = labels[train_test_split]
test_x = segments[~train_test_split]
test_y = labels[~train_test_split]

#---------------
#得到权重变量
def weight_variable(shape):
    initial = tf.truncated_normal(shape, stddev = 0.1) #截断的随机分布输出，保证生成值在均值附近
    return tf.Variable(initial)

#得到偏置变量
def bias_variable(shape):
    initial = tf.constant(1.0, shape = shape)
    return tf.Variable(initial)

#卷积
#num_channels：可理解为当前层的feature map的个数（filter个数）
#depth：是将要得到的feature map个数（filter个数）
def apply_conv(x,kernel_height,kernel_width,num_channels,depth):
    weights = weight_variable([kernel_height, kernel_width, num_channels, depth])
    biases = bias_variable([depth])
    return tf.nn.relu(tf.add(tf.nn.conv2d(x, weights,[1,1,1,1],padding="VALID"),biases)) #relu:计算激活函数，即max(features, 0)

#max pool
#stride_size：步幅大小，应用max后向后滑动的元素个数    
def apply_max_pool(x,kernel_height,kernel_width,stride_size):
    return tf.nn.max_pool(x, ksize=[1, kernel_height, kernel_width, 1], strides=[1, 1, stride_size, 1], padding = "VALID")

#---------------	
#基本常量
num_labels = 1
batch_size = 2
num_hidden = 800
learning_rate = 0.0001
training_epochs = 30
input_height = 24
input_width = 15
num_channels = 1
total_batches = train_x.shape[0] #有多少个24*15的segment

#---------------
X = tf.placeholder(tf.float32, shape=[None,input_height,input_width,num_channels])
Y = tf.placeholder(tf.float32, shape=[None,num_labels])

#定义两个卷积和pool层
c = apply_conv(X, kernel_height = 24, kernel_width = 4, num_channels = 1, depth = 8) 
p = apply_max_pool(c,kernel_height = 1, kernel_width = 2, stride_size = 2) 
c = apply_conv(p, kernel_height = 1, kernel_width = 3, num_channels = 8, depth = 14) 
p = apply_max_pool(c,kernel_height = 1, kernel_width = 2, stride_size = 2) 

shape = p.get_shape().as_list()
flat = tf.reshape(p, [-1, shape[1] * shape[2] * shape[3]])#横向展开

#前向传播

#输入计算
f_weights = weight_variable([shape[1] * shape[2] * shape[3], num_hidden])
f_biases = bias_variable([num_hidden])
f = tf.nn.tanh(tf.add(tf.matmul(flat, f_weights),f_biases))

#输出计算
out_weights = weight_variable([num_hidden, num_labels])
out_biases = bias_variable([num_labels])
y_ = tf.add(tf.matmul(f, out_weights),out_biases)

#---------------
#后向传播
cost_function = tf.reduce_mean(tf.square(y_- Y))#损失函数
optimizer = tf.train.AdamOptimizer(learning_rate).minimize(cost_function)#梯度下降

import time
f = open("output_cnn_rul_debug.txt", "a+")
f.write(time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))+"\n")
f.write("-------------------\n")
#---------------
#计算图
with tf.Session() as session:
    tf.global_variables_initializer().run()
    print("Training set MSE")
    for epoch in range(training_epochs): #每一个epoch后，会执行权重更新
        for b in range(total_batches):    
            offset = (b * batch_size) % (train_x.shape[0] - batch_size)
            batch_x = train_x[offset:(offset + batch_size), :, :, :]
            batch_y = train_y[offset:(offset + batch_size),:]
            _, c = session.run([optimizer, cost_function],feed_dict={X: batch_x, Y : batch_y})
         
            '''
            if offset==0:
                print session.run(out_weights)[0:10,:]
            '''
        #pdb.set_trace() 

        p_tr = session.run(y_, feed_dict={X:  train_x})
        tr_mse = tf.reduce_mean(tf.square(p_tr - train_y))
        f.write("\nepoch:%d mse:%.4f"%(epoch,session.run(tr_mse)))
       
        tmp = abs(p_tr-train_y)/train_y
        accuracy = (1-tf.reduce_mean(tmp[0]))*100
        f.write("   accuracy: %.2f"%session.run(accuracy))

        print(session.run(accuracy))
        print(session.run(tr_mse))

    p_ts = session.run(y_, feed_dict={X:  test_x})
    ts_mse = tf.reduce_mean(tf.square(p_ts - test_y))
    f.write("\nTest set MSE: %.4f" % session.run(ts_mse))

    tmp = abs(p_ts-test_y)/test_y
    accuracy = (1-tf.reduce_mean(tmp[0]))*100
    #p_acc = session.run(accuracy, feed_dict={X:test_x, Y:test_y})
    f.write("\nTest Accuracy: %.2f"%session.run(accuracy))

f.write("\n\n")
f.close()




