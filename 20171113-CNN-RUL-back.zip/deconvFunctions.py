#coding=utf-8
import numpy as np
#import pdb

def get_activations(weights):
    #test
    activations = list()
    activation = np.arange(1,7).reshape((1,6))
    activations.append(activation)
    return activations

def apply_unpool(conv_v, pool_v, pwidth, stride, padding='VALID'):
    res = np.array(list())
    for i in range(conv_v.shape[-1]):
        c = conv_v[...,i]
        p = pool_v[...,i]
        c = c[...,np.newaxis]
        p = p[...,np.newaxis]
        unpool = unpooling(c, p, pwidth, stride, padding='VALID')
        if i==0 :
            res = unpool
        else:
            res = np.append(res, unpool, axis=3)
    return res
#conv:pool前的conv， relu后得到的特征图，对应于activation的返回去的那个特征图，二维
#activation:是pool的输出的某一个显著值
#pwidth:max_pool的宽
#stride:pool的步长
def unpooling(conv, activation, pwidth, stride, padding='VALID'):
    #pooling的过程是oshape>kshape>activation.shape
    #unpooling过程是actiavation.shape>kshape>oshape
    #数据一定row只有一行
    conv = conv.reshape((conv.shape[0]*conv.shape[1]*conv.shape[2]*conv.shape[3]))
    activation = activation.reshape((activation.shape[0]*activation.shape[1]*activation.shape[2]*activation.shape[3]))
    #owidth:pool的输入的任意特征图的宽
    switches = list()
    les = 0;
    owidth = len(conv)
    if padding=='SAME':
        tmp = owidth%stride #stride<=pwidth
        if tmp>0 or  pwidth>stride:
            les = pwidth-tmp
            if tmp==0:
                les = stride
            #补0
            conv = np.append(np.zeros(les/2),conv)
            conv = np.append(conv, np.zeros(les-les/2))

    owidth = len(conv)
    #计算最大值位置
    for i in range(0, owidth, stride):
        maxn=conv[i];
        maxp=i;
        if i+pwidth > owidth:#drop
            break
        for j in range(i, i+pwidth):
            if maxn<conv[j]:
                maxn=conv[j]
                maxp=j
        switches.append(maxp)
    
    o = np.zeros(owidth, dtype='float32')
    #放回最大值位置
    for i in range(len(switches)):
        o[switches[i]] = activation[i]
    
    #pdb.set_trace()

    #恢复padding的影响
    if les>0:
        o = o[(les/2):-(les-les/2)]
    return o.reshape((1,1,len(o),1))
'''
#TEST CASE
conv = np.arange(1, 13)
activation = np.arange(1, 7)
pwidth = 5
stride = 3
owidth = 12
conv = conv.reshape((1,12))
activation = activation.reshape((1,6))

o = unpooling(conv, activation, pwidth, stride, padding='SAME')

print "卷积输出"
print conv
print "pool宽%d, pool步长%d"%(pwidth, stride)
print "pool输出"
print activation
print "反卷积结果"
print o
'''
