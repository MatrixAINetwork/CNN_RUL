#coding=utf-8
import pandas as pd
import numpy as np
#import tensorflow as tf
from sklearn.preprocessing import scale

#数据分段
def segment_signal(features,labels,window_size = 15): #（特征数据，数据对应标签，窗口大小默认15）
    segments = np.empty((0,window_size)) #返回未初始化的shape形状数据，此处相当于声明了个15列的变量
    segment_labels = np.empty((0)) #此处相当于申请了变量
    nrows = len(features) 
    for (start, end) in windows(nrows,window_size): #从生成器返回所有的窗口
        if(len(data.iloc[start:end]) == window_size):
            segment = features[start:end].T  #转置，得到24 x 15，相当于一个属性一行 
            '''
            if start==0:
                print segment
            '''
            label = labels[(end-1)]
            segments = np.vstack([segments,segment]) #垂直堆叠
            segment_labels = np.append(segment_labels,label) #一行数据
    print segments[0]
    segments = segments.reshape(-1,24,window_size,1) #batch_size不用管所以设为-1，channel也设为1 
    #print segments[0]
    segment_labels = segment_labels.reshape(-1,1) #获得一列，行数根据实际展开
    return segments,segment_labels 

def windows(nrows, size):
    start,step = 0, 2
    while start < nrows:
        yield start, start + size
        start += step


data = pd.read_csv("PHM08.csv", nrows=40)
#print data
features = scale(data.iloc[:,2:26]) # select required columns and scale them
labels = data.iloc[:,26] # select RU 

segments, labels = segment_signal(features,labels)
#print len(segments)

train_test_split = np.random.rand(len(segments)) < 0.70
train_x = segments[train_test_split]
train_y = labels[train_test_split]
test_x = segments[~train_test_split]
test_y = labels[~train_test_split]

'''
print train_x.shape[:]
print test_x.shape[:]
print train_test_split
print len(train_x)
print len(test_x)
'''
