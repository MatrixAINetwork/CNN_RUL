#cnn_rul_debug_savemodel.py
#TODO
model_file_name = 'model_20171104_896ac.pkl'

#cnn_rul_debug_deconResult_sep.py
model_rev_sep_file_name = 'model_rev_sep'+model_file_name[5:]

#cnn_rul_debug_deconResult_mul.py
model_rev_mul_file_name = 'model_rev_mul'+model_file_name[5:]

#deconvFunctions.py
model_rev_file_name = model_rev_mul_file_name
