#--coding=utf-8--
import helpFunctions as hf
import numpy as np
import matplotlib.pyplot as plt
import pdb
import os
import model_constant as mc
#model = hf.readdic("model.pkl")
#model_dev = hf.readdic('model_rev.pkl')
#model_dev = hf.readdic('model_rev_20171101_81ac.pkl')
model_dev = hf.readdic(mc.model_rev_file_name) 
#[batch_size, width, height, channels]
input_v = model_dev['input']
l1 = model_dev['l1']
l2 = model_dev['l2']

batch_size = input_v.shape[0]
varnum = input_v.shape[1]
timelen = input_v.shape[2]

'''
将制定输入的指定层的重建结果输出到同一张图
-----------------------------------------
im:一张输入图片
im_no:输入图片的编号
layer_recons: 某一层重建后的输入数据
layer_no：第几层的重建

得到一张图
'''
def saveLayerReconsInOne(im, im_no, layer_recons, layer_no):
    channel = layer_recons.shape[-1]
    plt.figure(figsize=(20,5*channel))
    plt.subplot((channel+1),1,1)
    plt.title("Original Data")
    plt.plot(im)
    for j in range(channel):
        l_t = layer_recons[im_no,...,j]
        #l2_t = l2[i,...,j]
        plt.subplot((channel+1),1,(j+2))
        plt.title("Layer1 Feature%d Reconstruction"%(j))
        plt.plot(l_t)
    file_name = get_file_name_path('test%d_all_l%d.png'%(im_no, layer_no), im_no);
    plt.savefig(file_name)

'''
输出指定层的重构与原始值的差值曲线
输出一张图
'''
def saveLayerReconsInOneOfDiff(im, im_no, layer_recons, layer_no):
    channel = layer_recons.shape[-1]
    varnum = im.shape[0]
    plt.figure(figsize=(20,5*channel))
    plt.title("Test%d Layer%d Feature Reconstruction"%(im_no, layer_no))
    for i in range(channel):
        plt.subplot(channel,1,(i+1))
        plt.title('Feature%d Reconstruction'%(i))
        l_t = layer_recons[im_no,...,i]
        for j in range(varnum):
            plt.plot(l_t[j]-im[j], label='Var %d'%(j))
    file_name = get_file_name_path('test%d_all_diff_l%d.png'%(im_no, layer_no), im_no);
    plt.savefig(file_name)

'''
输出所有输入，所有层重构后的差值图
'''
def checkAllReconsInOneOfDiff(input_start, input_end, input_data, layer_nums):
    for i in range(input_start, input_end+1):
        im = input_data[i,...,0]
        for j in range(1,layer_nums+1):
            saveLayerReconsInOneOfDiff(im, i, model_dev['l%d'%j], j)




'''
输出所有输入的所有层重构后的数据变化曲线
---------------------------------------
input_start: 输入数据集的开始index
input_end：输入数据集的结束index
input_data：输入数据集
layer_nums：有几层网络进行了重建操作
'''
def checkAllReconsInOne(input_start, input_end, input_data, layer_nums):
    #print input_end
    for i in range(input_start, input_end+1):
        im = input_data[i,...,0]
        for j in range(1,layer_nums+1):
            saveLayerReconsInOne(im, i, model_dev['l%d'%j], j)

'''
获得需要保存的文件的路径
------------------------
file_name：文件名称
'''
def get_file_name_path(file_name, im_no):
    cur_dir = os.getcwd()#获得当前路径
    
    folder_name = 'deconvResultCheck_figs/'+mc.model_rev_file_name[:-4]
    new_dir = os.path.join(cur_dir, folder_name)
    if(os.path.exists(new_dir) == False):
        os.mkdir(new_dir)
 
    folder_name = 'deconvResultCheck_figs/'+mc.model_rev_file_name[:-4]+'/test%d'%im_no
    new_dir = os.path.join(cur_dir, folder_name)
    if(os.path.exists(new_dir) == False):
        os.mkdir(new_dir)
    
    return new_dir+'/'+file_name;

'''
给定输入
将输入的每个属性分别与重构后的属性值进行对比
-----------------------------------------
im:一张输入图片
im_no:输入图片的编号
layer_recons: 某一层重建后的输入数据
layer_no：第几层的重建

多少个channel，多少张图
即每个特征得一张
'''
def saveLayerReconsInSeperate(im, im_no, layer_recons, layer_no):
    channel = layer_recons.shape[-1]
    varnum = im.shape[0]
    row = (varnum+1)/2
    #channel = 1 #TODO
    for i in range(channel):
        l_t = layer_recons[im_no,...,i]
        #pdb.set_trace()
        plt.figure(figsize=(20,5*row))
        for j in range(varnum):
            plt.subplot(row,2,j+1)
            plt.plot(im[j])
            plt.plot(l_t[j])
            plt.title('Variable%d'%(j))
        file_name = get_file_name_path('test%d_sig_l%d_f%d.png'%(im_no, layer_no, i), im_no)#名称含义：test0_sig_l1_f0 = 输入0号图片_每个属性单一输出_第1层的重构_第0号特征
        plt.savefig(file_name)

'''
给定输入
将输入的每个属性分别与重构后的属性值进行对比
输出差值曲线
-----------------------------------------
im:一张输入图片
im_no:输入图片的编号
layer_recons: 某一层重建后的输入数据
layer_no：第几层的重建

多少个channel，多少张图
即每个特征得一张
'''
def saveLayerReconsInSeperateOfDiff(im, im_no, layer_recons, layer_no):
    channel = layer_recons.shape[-1]
    varnum = im.shape[0]
    row = (varnum+1)/2
    #channel = 1 #TODO
    for i in range(channel):
        l_t = layer_recons[im_no,...,i]
        #pdb.set_trace()
        plt.figure(figsize=(20,5*row))
        for j in range(varnum):
            plt.subplot(row,2,j+1)
            plt.plot(l_t[j]-im[j])
            plt.title('Variable%d Reconstruction'%(j))
            plt.ylim(-2,2)
        file_name = get_file_name_path('test%d_sig_diff_l%d_f%d.png'%(im_no, layer_no, i), im_no)#名称含义：test0_sig_l1_f0 = 输入0号图片_每个属性单一输出_第1层的重构_第0号特征
        plt.savefig(file_name)

'''
输出所有输入的所有层重构后的数据变化曲线
---------------------------------------
input_start: 输入数据集的开始index
input_end：输入数据集的结束index
input_data：输入数据集
layer_nums：有几层网络进行了重建操作
'''
def checkAllReconsInSeperate(input_start, input_end, input_data, layer_nums):
    for i in range(input_start, input_end+1):
        im = input_data[i,...,0]
        for j in range(1,layer_nums+1):
            saveLayerReconsInSeperate(im, i, model_dev['l%d'%j], j)
'''
输出所有特征重构与原始输入的差值曲线图
'''
def checkAllReconsInSeperateOfDiff(input_start, input_end, input_data, layer_nums):
    for i in range(input_start, input_end+1):
        im = input_data[i,...,0]
        for j in range(1,layer_nums+1):
            saveLayerReconsInSeperateOfDiff(im, i, model_dev['l%d'%j], j)


if __name__ == '__main__':
    input_start = 0
    input_end = input_v.shape[0]-1
    input_data = input_v
    layer_nums = 2
    checkAllReconsInOne(input_start, input_end, input_data, layer_nums)
    checkAllReconsInSeperate(input_start, input_end, input_data, layer_nums)
    checkAllReconsInOneOfDiff(input_start, input_end, input_data, layer_nums)
    checkAllReconsInSeperateOfDiff(input_start, input_end, input_data, layer_nums)
