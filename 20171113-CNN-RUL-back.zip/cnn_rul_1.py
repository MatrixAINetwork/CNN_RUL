#coding=utf-8
import pandas as pd
import tensorflow as tf
import numpy as np
from sklearn.preprocessing import scale

#返回的是生成器
#下次调用，继续执行循环
#遇到yield就返回
#返回window的起始位置
def windows(nrows, size):
    start, step = 0, 2;
    while start<nrows:
        yield start, start+size
        start += step

def segment_signal(features, labels, window_size=15):
    segments = np.empty((0, window_size))
    segment_labels = np.empty((0))
    nrows = len(features)
    for (start, end) in windows(nrows, window_size):
        if(len(data.iloc[start:end])==window_size): #iloc-按照行号取得行数据
            segment = features[start:end].T #进行转置，获得24*15的size
            label = labels[(end-1)]
            segments= np.vstack([segments, segment])
            segment_labels = np.append(segment_labels, label)
    segments = segments.reshape(-1, 24, window_size, 1)
    segment_labels = segment_labels.reshape(-1,1) #变成一列
    return segments, segment_labels

data = pd.read_csv("data_set/PHM08.csv")
features = scale(data.iloc[:,2:26])
labels = data.iloc[:,26] #RUL

segments, labels = segment_signal(features, labels)

train_test_split = np.random.rand(len(features)) < 0.7.0
train_x = segments[train_test_split]
train_y = labels[train_test_split]
test_x = segments[~train_test_split]
test_y = labels[~train_test_split]

def weigt_variable(shape):
    initial = tf.truncted_normal(shape, stddev=0.1) #截断的产生正太分布的函数，该函数产生的随机数与均值的差距不会超过两倍的标准差
    return tf.Variable(initial)

def bias_variable(shape):
    initial = tf.constant(1.0, shape=shape)
    return tf.Variable(initial)

def apply_conv(x, kernel_height, kernel_width, num_channels, depth):
    weights = weight_variable([kernel_width, kernel_height, depth])
    biases = bias_variable([[depth]])
    return tf.nn.relu(tf.add(tf.nn.conv2d(x, weights, [1,1,1,1], padding="VALID"), biases)) #relu是激活函数，是连续但是不平滑的非线性函数

def apply_max_pool(x, kernel_height, kernel_width, stride_size):
    return tf.nn.max_pool(x, ksize=[1, kernel_height, kernel_width, 1], strides=[1,1,stride_size,1], padding="VALID")

num_labels = 1
batch_size = 10
num_hidden = 800
learning_rate = 0.0001
training_epochs = 30
input_height = 24
input_width = 15
num_channels = 1
total_batches = train_x.shape[0]

X = tf.placeholder(tf.float32, shape=[None, input_height, input_width, num_channels])
Y = tf.palceholder(tf.float32, shape=[None, num_labels])

c = apply_conv(X, kernel_height=24, kernel_width=4, num_channels=1, depth=8)
p = apply_max_pool(c, kernel_height=1, kernel_width=2, stride_size=2)
c = apply_conv(p, kernel_height=1, kernel_width=3, num_channels=8, depth=14)
p = apply_max_pool(c, kernel_height=1, kernel_width=2, stride_size=2)

shape = p.get_shape().as_list()
flat = tf.reshape(p, [-1, shape[1]*shape[2]*shape[3]])

f_weights = weigt_variable([shape[1]*shape[1]*shape[2], num_hidden])
f_biases = bias_variable([num_hidden])
f = tf.nn.tanh(tf.add(tf.matmul(flat, f_weights), f_biases))

out_weights = weigt_variable([num_hidden, num_labels])
out_biases = bias_variable([num_hidden])
y_ = tf.add(tf.matmul(f, out_weights), out_biases)

cost_function = tf.reduce_mean(tf.square(y_-Y))
optimizer = tf.train.AdamOptimizer(learning_rate),minimize(cost_function)

with tf.Session() as session:
    tf.global_variable_initializer().run()
    print "Training set MSE"
    for epoch in range(training_epochs):
        for b in range(total_batches):
            offset = (b*batch_size)%(train_x.shape[0]-batch_size)
            batch_x = train_x[offset:(offset+batch_sizef), :, :, :]
            batch_y = train_y[offset:batch_size, :]
            _, c = session.run([optimizer, cost_function], feed_dict={X:batch_x, Y:batch_y})

        p_tr = session.run(y_, feed_dict={X:train_x})
        tr_mse = tf.reduce_mean(tf.square(p_tr-train_y))
        print session.run(tr_mse)

    p_ts = session.run(y_, feed_dict={X:test_x})
    ts_mse = tf.reduce_mean(tf.square(p_ts-test_y))
    print "test set mse:%.4f" % session.run(ts_mse)


























    

